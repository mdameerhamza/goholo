<?php













return array(
  'authorizationRequestUrl' => 'https://appcenter.intuit.com/connect/oauth2', //Example https://appcenter.intuit.com/connect/oauth2',
  'tokenEndPointUrl' => 'https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer', //Example https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer',
  'client_id' => 'Q0PGBYwNj2MazWdKIo5gc4XelXDV6HI3LOmRJ8ITzNVY80VXho', //Example 'Q0wDe6WVZMzyu1SnNPAdaAgeOAWNidnVRHWYEUyvXVbmZDRUfQ',
  'client_secret' => 'lGW17LAYBugXJw4g2lQCYhhjOAPtyyzwmpWSwJIL', //Example 'R9IttrvneexLcUZbj3bqpmtsu5uD9p7UxNMorpGd',
  'oauth_scope' => 'com.intuit.quickbooks.accounting', //Example 'com.intuit.quickbooks.accounting',
  'openID_scope' => '', //Example 'openid profile email',
  'oauth_redirect_uri' => 'http://localhost/goholo/quickbooks/auth2/OAuth_2/OAuth2PHPExample.php', //Example https://d1eec721.ngrok.io/OAuth_2/OAuth2PHPExample.php',
  'openID_redirect_uri' => '',//Example 'https://d1eec721.ngrok.io/OAuth_2/OAuthOpenIDExample.php',
  'mainPage' => 'http://localhost/goholo/quickbooks/auth2/OAuth_2/index.php', //Example https://d1eec721.ngrok.io/OAuth_2/index.php',
  'refreshTokenPage' => 'http://localhost/goholo/quickbooks/auth2/OAuth_2/RefreshToken.php', //Example https://d1eec721.ngrok.io/OAuth_2/RefreshToken.php'
)
 ?>
